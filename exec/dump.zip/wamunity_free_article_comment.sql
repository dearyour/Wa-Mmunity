-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: database-wamunity.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: wamunity
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `free_article_comment`
--

DROP TABLE IF EXISTS `free_article_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `free_article_comment` (
  `comment_id` int NOT NULL AUTO_INCREMENT,
  `article_id` int NOT NULL,
  `member_id` int NOT NULL COMMENT 'Comment',
  `content` text NOT NULL,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `free_article_comment`
--

LOCK TABLES `free_article_comment` WRITE;
/*!40000 ALTER TABLE `free_article_comment` DISABLE KEYS */;
INSERT INTO `free_article_comment` VALUES (1,6,0,'댓글 test','2022-03-18 07:29:47'),(2,6,3,'댓글입니다라리라리','2022-03-18 18:32:45'),(3,1,26,'zz','2022-04-07 10:33:06'),(4,9,28,'','2022-04-07 02:30:57'),(5,7,0,'fdggd','2022-04-07 12:33:17'),(6,7,0,'dsf','2022-04-07 12:39:45'),(7,9,28,'ewrwe','2022-04-07 12:40:52'),(8,9,28,'fghfghfg','2022-04-07 12:42:06'),(9,9,28,'kj','2022-04-07 12:42:33'),(10,9,28,'asd','2022-04-07 12:51:05'),(11,9,28,'asfsa','2022-04-07 12:51:25'),(12,9,28,'dafad','2022-04-07 12:51:27'),(13,9,28,'sdf','2022-04-07 12:55:05'),(14,9,28,'asd','2022-04-07 12:55:28'),(23,6,26,'p[[p[p','2022-04-07 13:20:34'),(28,7,26,'kjjjk','2022-04-07 13:44:20'),(38,9,26,'jkjk','2022-04-07 16:41:38'),(46,9,26,'ㅇ나녕마아느날어ㅣㅇ러','2022-04-07 20:21:30'),(48,9,26,'ㅣㅣ;','2022-04-07 20:25:38'),(49,12,26,'이건 왜 사진등록된거지?????????????????','2022-04-07 22:49:59'),(50,12,26,'왜???????????????','2022-04-07 22:50:01'),(51,17,26,'wer','2022-04-07 23:30:00'),(52,17,26,'\'','2022-04-07 23:34:33'),(53,17,26,'\'','2022-04-07 23:34:33'),(54,15,26,'adasd','2022-04-07 23:38:19'),(55,16,26,'qwrqwrqwr','2022-04-08 00:06:33'),(56,16,39,'안녕하새요','2022-04-08 00:15:18'),(57,19,26,'pp[pi\\','2022-04-08 00:26:37'),(59,19,26,'iopiopiop','2022-04-08 00:26:42'),(60,19,26,'kkklj;','2022-04-08 00:26:44'),(62,21,26,'vbnvb','2022-04-08 03:32:09'),(67,29,26,'ㄷㅅㄷㄳ','2022-04-08 07:35:37'),(69,29,26,'ㄷㄳㄷㄳㄷㅅ','2022-04-08 07:36:05'),(70,32,26,'나한테왜이래진짜','2022-04-08 07:59:52'),(71,39,39,'오 뭔가 맛있을거같애요 ㅎㅎ','2022-04-08 10:11:55'),(72,41,39,'헐랭 꿀정보 감사요~~','2022-04-08 10:13:35'),(73,45,23,'판매완료','2022-04-08 10:21:22'),(74,45,45,'판매자입니다. 팔리지도 않았는데 왜 판매완료 답글 달았나요?','2022-04-08 10:22:59'),(76,45,46,'빅토리 저분 여기 빌런임..,,ㅠ 제 글에도 판매완료 남김 ','2022-04-08 10:33:14'),(77,44,46,'와 현우님 그렇게 안봤는데 좀 실망이네요,,,','2022-04-08 10:33:36'),(78,43,46,'당연히 와뮤니티말이맞죠 ','2022-04-08 10:35:17'),(79,42,46,'ㅋㅋㅋㅋ허세','2022-04-08 10:35:56'),(80,40,46,'프랑스에서 유행한다고 하네요','2022-04-08 10:36:15'),(81,39,46,'얼마정도하죠','2022-04-08 10:36:22'),(82,38,46,'가격을 먼저 올리셔야 하지 않을까요?','2022-04-08 10:36:33'),(83,43,26,'이탈리아산이 최곱니다','2022-04-08 11:09:32');
/*!40000 ALTER TABLE `free_article_comment` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:25:04
