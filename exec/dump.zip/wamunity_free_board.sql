-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: database-wamunity.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: wamunity
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `free_board`
--

DROP TABLE IF EXISTS `free_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `free_board` (
  `article_id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL COMMENT 'Comment',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `photo` text,
  `tag` text,
  `regtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `free_board`
--

LOCK TABLES `free_board` WRITE;
/*!40000 ALTER TABLE `free_board` DISABLE KEYS */;
INSERT INTO `free_board` VALUES (38,26,'쟁여놓은 와인 새것 팝니다','https://open.kakao.com/o/grLrKPYb\r\n\r\n생각하시는 가격 오픈채팅으로 말씀해주세요!\r\n그 가겨에 드립니다!!','https://wamunity-01-s3.s3.ap-northeast-2.amazonaws.com/freeboard/f36fdcda-b5d5-4196-bdf7-f68b106907b2-profileimage','판매','2022-04-08 10:09:13'),(39,40,'친환경 와인 나왔다네요 ㄷㄷ','친환경 와인은 뭐죠???? 포도가 좋은가 ,,','https://wamunity-01-s3.s3.ap-northeast-2.amazonaws.com/freeboard/9c31856f-ea1e-4ccb-a05a-16aea91babed-profileimage','일상','2022-04-08 10:10:14'),(40,40,'와인장종류','이런 와인장 종류는 첨봅니다,,','https://wamunity-01-s3.s3.ap-northeast-2.amazonaws.com/freeboard/00ffe357-2152-48a8-b749-904987ee8ff7-profileimage','일상','2022-04-08 10:11:01'),(41,44,'홈플 추천와인','홈플 추천와인 떴습니다 허허 오늘 다뿌실겁니다','https://wamunity-01-s3.s3.ap-northeast-2.amazonaws.com/freeboard/a19ae356-f5d3-4535-9bbf-77c311ad473c-profileimage','일상','2022-04-08 10:12:13'),(42,34,'무알콜와인','세상에 무 알콜 와인이 말이 됩니까????? \r\n그럴거면 물을먹지 왜먹습니까 참나 ','https://wamunity-01-s3.s3.ap-northeast-2.amazonaws.com/freeboard/cb152d50-97b6-4eaf-ad13-5685700503ec-profileimage','일상','2022-04-08 10:13:14'),(43,16,'와인1위 원산지','칠레산이라네요 와뮤니티는은 리뷰 1위들 다 프랑스산이던데 \r\n누구 말이 맞는건가요??','https://wamunity-01-s3.s3.ap-northeast-2.amazonaws.com/freeboard/3d3a91aa-cf93-4b55-9667-3a6137b0c529-profileimage','리뷰','2022-04-08 10:14:07'),(44,41,'인생와인','대단한거 하나 찾았습니다 마누라 몰래 저 혼자 먹고있습니다 키키','https://wamunity-01-s3.s3.ap-northeast-2.amazonaws.com/freeboard/a22cce3f-84cc-4fdc-8741-4af09763d6c3-profileimage','리뷰','2022-04-08 10:15:56'),(45,44,'핑크 모스카토 로제와인','모스카토 판매합니다 결혼기념일 선물받은건데 저희 부부가 술을 안해서요\r\n연락주세요\r\nhttps://open.kakao.com/o/grLrKPYb','https://wamunity-01-s3.s3.ap-northeast-2.amazonaws.com/freeboard/217da7bc-6eab-4076-b1ab-19fe36d71498-profileimage','판매','2022-04-08 10:18:06');
/*!40000 ALTER TABLE `free_board` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:23:31
