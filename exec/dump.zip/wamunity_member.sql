-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: database-wamunity.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: wamunity
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_adult` tinyint NOT NULL,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (16,'wonsik2','wonsik@gmail.com','$2a$10$OZQ2f4Ysgb8gM2q14.R8s.m3uBJogSc0EFXxS29EZWAUCOMpTlxU2',1,'2022-03-22 07:39:20'),(21,'minj','minj@gmail.com','$2a$10$5pVSPZGPuMOmxOQfLxMVz.jo/4KOa2JljB3.MEkGpUVGwAkZwQsuG',1,'2022-03-22 07:39:20'),(22,'coffee','coffee@gmail.com','$2a$10$6ss8iL.cF.fALqQSZ97aMeS3RDkJ/Vh/WOOQbCef/m7oHjgZozPJe',1,'2022-03-22 16:41:02'),(23,'victoria','victoria@gmail.com','$2a$10$w9LQyrDQN7BaXcfjWgU.XeoCF2F4mJRHo.xRz0NCjvoGuDIOF8fy.',1,'2022-04-02 17:45:53'),(24,'alive','alive@gmail.com','$2a$10$ZeRiFzFBWVILZ9UXDRjjYeV3cRJ4359CHNk2ZWutWmITgXSdKNu.C',0,'2022-04-04 03:16:32'),(25,'qwerqwer','qwerqwer@naver.com','$2a$10$YFVniFCunUCGjxDKvR0CuOc728t6L6HC7T83ex2/rmCj.48chg70C',0,'2022-04-04 03:32:31'),(26,'말하는감자','qwer@qwer.com','$2a$10$WCpTeBHndyH2X3pymNOPqu0PFvQfXsvBArmjBa8CJKbruFi/eF8kC',0,'2022-04-04 04:09:45'),(27,'qwe','qwe@qwe.com','$2a$10$2ntZvA/.XlOFoF2P3ytg5O2q38fILQPx8Qx8wJiB8.ajaqhObt7hm',0,'2022-04-05 03:55:33'),(28,'minjung','3sally@naver.com','$2a$10$nuSwxXYkveWFoSPgoym9F.Q/GhG5lzrIS0TMeXkcAjMkjKdVAbcG2',0,'2022-04-05 14:36:45'),(29,'tbja1703','tbja.ssafy@gmail.com','$2a$10$hTEn9NuY0yaf6943XsytG.xVOkjaqZiwsAsRZn1GlDGDMOoUIYzgi',0,'2022-04-05 14:42:06'),(30,'coach','cnnnnh@gmail.com','$2a$10$2sdMFmslyTQ3T3AnZiP/PeajOsB1FZZ9v.4Sk8NhQzhVKMAoQQ5rC',0,'2022-04-05 14:47:45'),(31,'지나가는사람','a@a.a','$2a$10$/BI9J16aVZYOzG.jj/1wcenEDGsRlGxP8aJAU7HvHaHPD8zen20Ba',0,'2022-04-05 17:49:41'),(32,'aa','aaa@cc.dd','$2a$10$4Q.9.QI4aIHIytxIO/kn5.pB3CoaWDz4ZyZqLNJONjIuS.wwiYDCm',0,'2022-04-06 00:27:13'),(33,'아기다리고기다리','dw3624@gmail.com','$2a$10$9iXkMd.JnPGOAJRSAJglr.vTeulZJBmWLrzailMl.a7rsQhofpj/2',0,'2022-04-06 10:45:08'),(34,'김명섭','kimms4142@naver.com','$2a$10$N2AUoECgtTGQA34SW7bzE.7/OvrxYxkEOlFO6rBuR5sfKkpT8lZ1C',0,'2022-04-06 10:51:57'),(35,'hakahaka','ddngrrim@gmail.com','$2a$10$SedGUIST6UtG1EktgmQaD.GAVF0l2T/NqDkFTFDoWt4StH0DXReUO',0,'2022-04-06 13:46:58'),(36,'aaa','wnal3309@naver.com','$2a$10$in4n7b9.4SpBEmKboFPVJOq05QbmiwqVW8zhotQGjGAEToSWUJd1C',0,'2022-04-07 01:49:15'),(37,'wineJJANG','loveWine@naver.com','$2a$10$0tL9SIfLJov5U6jhSdN0bed1lCdsbk8yMSgkwZ8wYZfRcuPtqIuuW',0,'2022-04-07 15:17:05'),(38,'bonobono','bonobono@naver.com','$2a$10$LqamuPU9kJq1GHVytEtau.RauFU.ButK6m5cDUZ4FEYuoO2F4qDCm',0,'2022-04-07 15:20:07'),(39,'mj','minjung@naver.com','$2a$10$P8Vg83kDRI6ip4e2.SBbqOWmJm19Ql7WVtF1QhaUbVpCXlJSpWrfe',0,'2022-04-07 16:48:00'),(40,'말하는 감자','asd@asd.com','$2a$10$DuReI0/O/4R.oV8H70krIeUabOpJ1d.FbursUUM5A7ar/Qzke0INi',0,'2022-04-07 23:42:22'),(41,'박현우박','qweadzs@naver.com','$2a$10$eddNa1Juc3xWX7.p6f7MI.hpT/9lV66BtYx.R8EkdRgINdp.XFx06',0,'2022-04-08 00:25:29'),(42,'홍승승','tmdrl5661@naver.com','$2a$10$1ttsnv1DU7XO4.2hVE0n9uZVk.iGzQ6MftA7Bs0TT/EDQE0Bdky4a',0,'2022-04-08 00:43:23'),(43,'ssafy','ssafy@ssafy.com','$2a$10$m7pRwFywsNe2qcKT02zphOd0ZL4v2zoXQcOn845Hh7BdIMYpzzl8S',0,'2022-04-08 03:51:06'),(44,'고주망태','as@as.com','$2a$10$ZnF/FPX4.HTOmErSHM.Ufu2mysAOjIT.iBq.9LHjMDe8cEKssYJOy',0,'2022-04-08 10:11:22'),(45,'고주망테','mang@gmail.com','$2a$10$lsdRhKglXAcVOznWk4B0.eb0HeJR.eY6HnSSm6dTlMoOV16laB0Ye',0,'2022-04-08 10:22:25'),(46,'와뮤고인물','qw@qw.com','$2a$10$97iOocYr0KAuLo7hQHg1juW1M/M62vr8a.ltI99xlsm9QIYx6bs7.',0,'2022-04-08 10:32:28');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:24:12
