-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: database-wamunity.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: wamunity
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `resell_board`
--

DROP TABLE IF EXISTS `resell_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resell_board` (
  `article_id` int NOT NULL AUTO_INCREMENT,
  `member_id` int NOT NULL COMMENT 'Comment',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `photo` text,
  `tag` text,
  `price` int NOT NULL,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resell_board`
--

LOCK TABLES `resell_board` WRITE;
/*!40000 ALTER TABLE `resell_board` DISABLE KEYS */;
INSERT INTO `resell_board` VALUES (1,1,'첫 글입니다.2','반갑습니다.','http://wamunity-01-s3.s3-website.ap-northeast-2.amazonaws.com/resellboard/3f293fb4-c47f-4182-b905-988c81c29344-testpng.png','판매',20000,'2022-03-24 12:26:24'),(2,1,'2 글입니다.','반갑습니다.','http://wamunity-01-s3.s3-website.ap-northeast-2.amazonaws.com/resellboard/2b51f758-f88c-47fa-a2ab-835758c8dafc-dada.png','판매',20000,'2022-03-23 15:31:05'),(4,26,'title','et','','1',45,'2022-04-07 01:14:19'),(5,16,'닉네임 테스트 글입니다.','닉네임 테스트 글입니다.','',NULL,15000,'2022-04-07 08:02:55'),(6,1,'테스트 입니다.','반갑습니다.','http://wamunity-01-s3.s3-website.ap-northeast-2.amazonaws.com/resellboard/59a9aff7-0c0f-44b1-9618-d407a28c4d56-dada.png','판매',20000,'2022-04-07 17:14:53'),(7,26,'3','3','http://wamunity-01-s3.s3-website.ap-northeast-2.amazonaws.com/resellboard/0bcf9f2a-7e04-489f-af91-c2c172b9f69f-%EA%B5%90%ED%99%98_%EB%82%A8%EC%95%85_%EC%98%81%EC%A4%91_Baram22011418273000.jpg','3',3,'2022-04-07 21:10:10'),(8,26,'3','3','http://wamunity-01-s3.s3-website.ap-northeast-2.amazonaws.com/resellboard/f3a6e681-990a-4f9e-8796-3a0973ec5c82-%EA%B5%90%ED%99%98_%EB%82%A8%EC%95%85_%EC%98%81%EC%A4%91_Baram22011418273001.jpg','3',3,'2022-04-07 21:18:36');
/*!40000 ALTER TABLE `resell_board` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:24:55
