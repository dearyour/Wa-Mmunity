-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: database-wamunity.cogsuiysl2rl.ap-northeast-2.rds.amazonaws.com    Database: wamunity
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `wine_review`
--

DROP TABLE IF EXISTS `wine_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wine_review` (
  `wine_review_id` int NOT NULL AUTO_INCREMENT,
  `wine_id` int NOT NULL,
  `member_id` int NOT NULL COMMENT 'Comment',
  `rating` double DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `regtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`wine_review_id`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wine_review`
--

LOCK TABLES `wine_review` WRITE;
/*!40000 ALTER TABLE `wine_review` DISABLE KEYS */;
INSERT INTO `wine_review` VALUES (89,222,27,4,'sad','2022-04-05 04:05:40'),(108,222,26,4,'erw','2022-04-05 04:56:05'),(116,1,26,2,'배가 너무나와욤,,','2022-04-05 07:48:07'),(120,2313,26,3,'히히 넘마시쪄욤 뿌우!','2022-04-05 14:59:36'),(122,2403,26,5,'진짜마시쪄욤','2022-04-05 15:35:38'),(124,234,26,5,'너무 맛있어요','2022-04-05 15:44:19'),(129,444,26,3,'노맛이에요!','2022-04-05 16:05:16'),(135,2333,26,4,'무야호','2022-04-06 01:48:24'),(138,2,26,5,'andigh~!!','2022-04-06 01:53:50'),(164,213,26,3,'맛있어용','2022-04-06 10:55:01'),(173,211,33,4,'aaaa','2022-04-06 12:04:00'),(174,2,33,3,'aaaah','2022-04-06 12:04:29'),(175,1,33,3,'ㅔㅔㅔ','2022-04-06 14:45:06'),(186,3,26,3,'너무 맛있어용!!!!!!_!!!!!!!!!!','2022-04-07 01:53:53'),(187,2318,37,4,'너무 맛있어요~ 치즈랑 먹으니깐 잘 어울렸어요','2022-04-07 15:18:59'),(188,2318,38,2,'으 제 입맛에는 좀 안 맞네요ㅠㅜ','2022-04-07 15:20:46'),(190,1953,24,4,'좋아하는 파스타에 곁들일 훌륭한 와인. 풍부하고 매끄러운 마무리.','2022-04-07 16:09:48'),(191,1,39,5,'헐 이거 존맛인디요~~','2022-04-07 16:48:56'),(192,2245,39,4,'이거 진짜 맛있습니다. 추천해요!!','2022-04-07 16:49:45'),(193,2240,39,5,'로제 와인에서는 이게 제일 맛있는거같아요 ㅎㅎ','2022-04-07 16:50:04'),(194,311,39,2,'아 이거는 좀 구렸습니다 맛이ㅜㅜ ','2022-04-07 16:50:22'),(195,235,39,5,'향이 너무 좋은 와인이에요 향에 취해요~','2022-04-07 16:50:50'),(196,1344,41,1,'맛없쪙','2022-04-08 00:26:53'),(197,2348,26,5,'2918년 숙성기간 실화입니까???????????','2022-04-08 03:55:03'),(198,2237,43,5,'홈파티 할 때 마셨봤는데 너무 맛있었어요~ 파스타랑 잘 어울려요','2022-04-08 04:12:20'),(199,106,43,2,'이건 뭔 맛인지 잘 모르겠네요ㅜ','2022-04-08 04:13:05'),(202,121,43,2,'제 입맛에는 무슨 맛인지 잘 모르겠더라고요ㅜ 치즈랑 먹으니깐 그나마 괜찮았습니다','2022-04-08 04:14:27'),(203,2636,43,3,'무난하게 마시기 좋았어요','2022-04-08 04:15:10'),(205,233,43,4,'소고기랑 찰떡이었습니다. 떫은맛이 매력적이네요','2022-04-08 04:15:46'),(209,0,24,5,'잘 익은 살구, 복숭아, 망고, 사과의 달콤한 향이 납니다. 훌륭합니다.','2022-04-08 09:48:33'),(211,4,24,4,'꿀, 파인애플, 복숭아 향이 나고 산도는 높습니다. 음식없이 마셔도 돼요','2022-04-08 09:52:14'),(212,3,24,5,'과일과 꽃 향기가 나고 바닐라, 크림 브륄레, 살구맛이 따라와요. 풀 바디, 우아한 산도, 풍부하고 긴 피니시.','2022-04-08 09:56:32'),(214,235,22,5,'이 와인 많이 마시게 돼요~ 체리, 초콜릿, 커피, 레더향이 나요. 길고 강한 피니쉬가 있어요.','2022-04-08 10:02:19'),(215,0,22,5,'리치 골드 색에 강한 단맛이 나고 복숭아, 망고, 사과향이 나요. 그리고 약간의 시트러스가 단맛을 깨고 들어와요. 복잡하지만 좋아요','2022-04-08 10:04:34'),(216,1,23,5,'정말 기억에 남는 와인이에요. 꿀, 메론, 백후추, 시나몬 향이 나고 정말 많은 레이어가 있네요. 실패하지 않을 선택.','2022-04-08 10:07:31'),(217,0,23,4,'아몬드 메이플 시럽. 애프터 디너 드링크로 좋음.','2022-04-08 10:08:58'),(218,211,23,5,'이건 뭔가요..! 꼭 트라이 해보세요. 바닐라, 오크, 레더, 발사믹 향이 나고 드라이하고 중간 정도의 산도에 풀 바디, 실키하고 크리미한 tannins... 블랙베리, 플럼, 발사믹도 있고 길게 남는 피니시까지!','2022-04-08 10:11:55'),(219,214,23,5,'아름답게 코에 남는 초콜릿과 약간 스모키한 향, 체리향, 자두향. 좋네요','2022-04-08 10:13:04'),(220,2639,23,4,'사과, 라임, 민트, 꿀의 향이 낭고 밸런스가 좋고 산도는 아주 좋네요.','2022-04-08 10:14:48'),(221,0,45,5,'정말 신선한 디저트 와인이네요. 슈가밤.','2022-04-08 10:25:14'),(222,2314,45,5,'입을 때리네요. 배와 사과향이 들어오는데 조화롭네요. 깊고 산도 밸런스가 좋습니다.','2022-04-08 10:27:23'),(223,214,45,5,'정말 우아하네요. 블랙 체리향과 함께 레더, 바닐라, 심지어 약간의 초콜릿 향까지 있어요. 최곱니다','2022-04-08 10:37:44'),(224,211,46,5,'오 네임드 빅토리아님 추천 ㄷㄷ믿고 삽니다','2022-04-08 10:38:02'),(225,211,45,5,'울트라 탑 와인','2022-04-08 10:39:45'),(226,2348,46,5,'이거 오늘 저녁에 뿌십니다!!!!!!!!!!!1','2022-04-08 10:39:56'),(228,3,45,5,'판타스틱. 골든 옐로우 색에 복숭아, 꿀 향도 나고 풀바디, 밸런스도 좋고, 우아한 산도, 리치하고 긴 마무으리','2022-04-08 10:42:58');
/*!40000 ALTER TABLE `wine_review` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:24:48
